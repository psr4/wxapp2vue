var host = "https://ol.qztywl.com";
function formatTime(date) {
	var year = date.getFullYear()
	var month = date.getMonth() + 1
	var day = date.getDate()

	var hour = date.getHours()
	var minute = date.getMinutes()
	var second = date.getSeconds()


	return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}
function formatNumber(n) {
	n = n.toString()
	return n[1] ? n : '0' + n
}
function getAjaxUrl(model) {
	return host + "/index.php/Api2-" + model + ".html";
}
function getAjaxData(model, data, func_s, method = "GET") {
	var app = getApp();
	if (app.loading == 1 || (app.globalData.login !== true && model != "login")) {
		console.log(model);
		setTimeout(function () {
			getAjaxData(model, data, func_s, method);
		}, 100);
		return;
	}
	app.loading = 1;
	wx.showLoading({
		title: '加载中',
		mask: true
	})
	var url = getAjaxUrl(model);
	data.token = app.globalData.token;//wx.getStorageSync('token');
	wx.request({
		url: url,
		data: data,
		method: method,
		header: {
			"Content-Type": "application/x-www-form-urlencoded"
		},
		success: function (data) {
			app.loading = 0;
			if (data.data.status == 0) {
				wx.hideLoading();
				app.globalData.login = false;
				setTimeout(function () {
					getAjaxData(model, data, func_s, method);
				}, 100);
				wx.showModal({
					title: '提示',
					content: '请授权程序登录',
					success() {
						wx.getSetting({
							success: (res) => {
								if (res.authSetting["scope.userInfo"] == true) {
									login()
								} else {
									wx.openSetting({
										success: (res) => {
											if (res.authSetting["scope.userInfo"] == true) {
												login()
											} else {
												wx.switchTab({
													url: '/pages/index/index',
												})
											}
										}
									})
								}
							}
						})
					}
				})
			} else {
				wx.hideLoading();
				func_s(data);
			}
		}, fail: function () {
			wx.hideLoading();
			getAjaxData(model, data, func_s, method);
		}
	})
}

function onShareAppMessage(e) {
	var app = getApp();
	var option = "?scene=" + app.globalData.user.id;
	for (var i in this.options) {
		option += "&" + i + "=" + this.options[i];
	}
	var indexurl = this.route + option;
	//var indexurl = "/pages/index/index?scene=" + app.globalData.user.id;
	var title;
	if (this.data.titlebar) {
		title = this.data.titlebar.title + "-";
	} else if (this.data.title) {
		title = this.data.title + "-";
	} else {
		title = app.globalData.title;
	}
	console.log(indexurl);
	return {
		title: title + app.globalData.title,
		path: indexurl
	}
}
function pay(data, fun_s) {
	getAjaxData("pay", data, function (res) {
		if (res.data.data.status) {
			wx.requestPayment({
				'timeStamp': res.data.data.api.timeStamp + "",
				'nonceStr': res.data.data.api.nonceStr + "",
				'package': res.data.data.api.package + "",
				'signType': 'MD5',
				'paySign': res.data.data.api.paySign + "",
				'success': function (res) {
					fun_s(res);
				},
				'fail': function (res) {
					console.log(res);
				}
			})
		} else {
			fun_s(res);
		}
	}, "POST")
}
function login(me, scene = wx.getStorageSync('scene')) {
	if (!me) {
		var me = getApp();
	}
	wx.login({
		success: function (res) {
			getAjaxData("login", { code: res.code, scene: scene }, function (result) {
				if (!result.data.data.error) {
					wx.setStorageSync('token', result.data.data.token);
					me.globalData.token = result.data.data.token;
					me.globalData.user = result.data.data.user;
					me.globalData.login = true;
					wx.getUserInfo({
						success: function (res) {
							console.log(res);
							me.globalData.userInfo.nickName = res.userInfo.nickName;
							me.globalData.userInfo.avatarUrl = res.userInfo.avatarUrl;
							res.userInfo.encryptedData = res.encryptedData;
							res.userInfo.iv = res.iv;
							getAjaxData("userinfo", res.userInfo, function (res) {
							}, "POST");
						},
						fail: function () {
							me.globalData.userInfo.nickName = "小程序会员";
							me.globalData.userInfo.avatarUrl = "/Tpl/home/jdred/Style/images/user.png";
							res.userInfo.encryptedData = res.encryptedData;
							res.userInfo.iv = res.iv;
							getAjaxData("userinfo", me.globalData.userInfo, function (res) {
							}, "POST");
						}
					})
				} else {
					wx.setStorageSync('token', "");
					wx.showModal({
						title: '登录失败',
						content: result.data.data.msg,
						success: function (res2) {
							wx.switchTab({
								url: '/pages/index/index',
							})
						}
					})
				}
			}, "POST")
		}
	})
}
function previewimage(e) {
	wx.previewImage({
		urls: [e.currentTarget.dataset.src]
	})
}
function parse_str(e){
	var preg = new RegExp(/&[^=]*=[^&]*/, "g");
	var array = []
	var data ;
	while (data = preg.exec("&" + e)){
		array.push(data[0].substring(1));
	}
	var obj ={};
	if (array.length > 0) {
		var npreg = new RegExp(/([^=]*)=([^&]*)/);
		for (var i = 0; i < array.length;i++){
			var d = npreg.exec(array[i]);
			obj[d[1]] = d[2];
		}
		return obj;
	}else{
		return false;
	}
}
module.exports = {
	host,
	getAjaxUrl,
	getAjaxData,
	formatTime,
	onShareAppMessage,
	previewimage,
	pay,
	login,
	parse_str
}
