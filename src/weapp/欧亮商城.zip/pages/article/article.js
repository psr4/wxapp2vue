//index.js
//获取应用实例
var util = require('../../utils/util.js')
var WxParse = require('../../wxParse/wxParse.js')
var app = getApp()
Page({
	data: {
		title: "商城分类",
		needpwd: 0
	},
	onLoad: function (options) {
		var me = this;
		util.getAjaxData("arcdata", { id: options.id }, function (res) {
			me.setData({
				needpwd: res.data.data.needpwd,
				arc: res.data.data.arc
			})
			WxParse.wxParse('article', 'html', res.data.data.arc.info, me, 5);
		});
	},
	submit(e) {
		var pwd = e.detail.value.pwd;
		var me = this;
		util.getAjaxData("arcdata", { id: this.options.id, pwd: pwd }, function (res) {
			me.setData({
				needpwd: res.data.data.needpwd,
				arc: res.data.data.arc
			})
			WxParse.wxParse('article', 'html', res.data.data.arc.info, me, 5);
		});
	},
	onPullDownRefresh: function () {
		this.onLoad();
		wx.stopPullDownRefresh()
	},
	onShareAppMessage: util.onShareAppMessage
})