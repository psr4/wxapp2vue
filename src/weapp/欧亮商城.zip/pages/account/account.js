var util = require('../../utils/util.js')
var app = getApp()
Page({
  data: {
      img:""
  },
  onLoad: function (options) {
    this.setData({
        user: app.globalData.user ,
        img: util.host +"/temp/account.jpg",
    })
  },
  onPullDownRefresh: function () {
      this.onShow();
      wx.stopPullDownRefresh()
  },
  onShareAppMessage: util.onShareAppMessage
})