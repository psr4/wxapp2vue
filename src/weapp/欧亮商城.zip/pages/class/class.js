//index.js
//获取应用实例
var util = require('../../utils/util.js')
var app = getApp()
Page({
    data: {
        title: "商城分类",
        class: [],
        classid: 0,
        index: 0,
        searchtxt: "",
        goods: [],
        load: [],
        menu:true,
        search:false,
        current:0
    },
    showmenu() {
      this.setData({
        menu: !this.data.menu
      })
    },
    showsearch() {
        var keyword = this.data.keyword;
        if (this.data.search && keyword){
            wx.navigateTo({
                url: '/pages/list/list?method=search&text=' + keyword,
            })
        } else {
            this.setData({
                search: !this.data.search
            })
        }
    },
    onLoad: function (options) {
        var me = this;
        util.getAjaxData("classes", {}, function (res) {
            var goods = me.data.goods;
            goods[res.data.data.cate[0].id] = res.data.data.goods;
            var load = me.data.load;
            load[res.data.data.cate[0].id] = true;
            me.setData({
                class: res.data.data.cate,
                classid: res.data.data.cate[0].id,
                name:res.data.data.cate[0].name,
                goods: goods,
                load:load
            })
        });
    },
    bindKeyInput: function (e) {
        this.setData({
            searchtxt: e.detail.value
        })
    },
    search: function (data) {
        wx.navigateTo({
            url: '/pages/list/list?method=search&text=' + this.data.searchtxt
        })
    },
    input(e){
        var keyword = e.detail.value;
        this.setData({
            keyword:keyword
        })
    },
    changeClass: function (data) {
        if (data.currentTarget.dataset.id == this.data.classid) return; 
        var me = this;
        var goods = me.data.goods;
        var load = me.data.load;
        var name = data.currentTarget.dataset.name;
        if (!load[data.currentTarget.dataset.id]) {
            util.getAjaxData("categoods", { id: data.currentTarget.dataset.id }, function (res) {
                goods[data.currentTarget.dataset.id] = res.data.data.goods;
                load[data.currentTarget.dataset.id] = true
                me.setData({
                    classid: data.currentTarget.dataset.id,
                    index: data.currentTarget.dataset.index,
                    name: name,
                    goods: goods,
                    load: load,
                    menu:0
                })
            });
        }else{
            me.setData({
                name: name,
                classid: data.currentTarget.dataset.id,
                index: data.currentTarget.dataset.index,
                menu: 0
            })  
        }
    },
    nexttap() {
        var current = this.data.current;
        if (current < this.data.goods[this.data.classid].length - 1){
            current++;
        }else{
            current = 0;
        }
        this.setData({
            current:current
        })
    },
    pretap() {
        var current = this.data.current;
        if (current >0) {
            current--;
        } else {
            current = this.data.goods[this.data.classid].length - 1;
        }
        this.setData({
            current: current
        })
    },
    itemlist: function (data) {
        wx.navigateTo({
            url: '/pages/list/list?method=class&id=' + data.currentTarget.dataset.id
        })
    },
    onPullDownRefresh: function () {
        this.onLoad();
        wx.stopPullDownRefresh()
    },
    onShareAppMessage: util.onShareAppMessage
})