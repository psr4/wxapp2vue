//index.js
//获取应用实例
var util = require('../../utils/util.js')
var app = getApp()
Page({
  data: {
    showtabbar:true
  },
  onLoad: function (options) {
    var me = this;
    util.getAjaxData("group", {}, function (res) {
      me.setData({
        group: res.data.data
      })
    }, "POST");
  },
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh()
  },
  onShareAppMessage: util.onShareAppMessage
})