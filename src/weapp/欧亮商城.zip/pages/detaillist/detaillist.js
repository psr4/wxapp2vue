//index.js
//获取应用实例
var util = require('../../utils/util.js')
var app = getApp()
Page({
  data: {
    titlebar: {
      title: "团队订单",
      back: 2
    },
    tabid:1,
    showtabbar: true
  },
  onLoad: function (options) {
    var me = this;
    util.getAjaxData("detaillist", {}, function (res) {
      me.setData({
        u1: res.data.data.u1,
        u2: res.data.data.u2
      })
    }, "POST");
  },
  changtab(e){
    this.setData({
      tabid:e.currentTarget.dataset.id
    })
  },
  onPullDownRefresh: function () {
    this.onLoad();
    wx.stopPullDownRefresh()
  },
  onShareAppMessage: util.onShareAppMessage
})