//index.js
//获取应用实例
var util = require('../../utils/util.js')
var app = getApp()
Page({
    data: {
        title: "商城首页",
        banner: [],
        tuijian: [],
        class: [],
        searchtxt: ""
    },
    onLoad: function () {
        app.globalData.scene = this.options.scene;
        var me = this;
        util.getAjaxData("index", this.options, function (res) {
            me.setData({
                banner: res.data.data.ad,
                tuijian: res.data.data.tuijian,
                class: res.data.data.class,
                coupon: res.data.data.coupon
            })
        }, "POST");
    },
    bindKeyInput: function (e) {
        this.setData({
            searchtxt: e.detail.value
        })
    },
    iteminfo: function (data) {
        wx.navigateTo({
            url: '/pages/detail/detail?id=' + data.currentTarget.dataset.id
        })
    },
    search: function (data) {
        wx.navigateTo({
            url: '/pages/list/list?method=search&text=' + this.data.searchtxt
        })
    },
    classlist: function (data) {
        wx.navigateTo({
            url: '/pages/detail/detail?id=' + data.currentTarget.dataset.id
        })
    },
    onPullDownRefresh: function () {
        this.onLoad();
        wx.stopPullDownRefresh()
    },
    onShareAppMessage: util.onShareAppMessage,
    previewimage: util.previewimage
})