//index.js
//获取应用实例
var util = require('../../utils/util.js')
var app = getApp()
Page({
    data: {
        title: "个人中心",
        user: {}
    },
    onShow: function () {
        var me = this;
        util.getAjaxData("my", { }, function (res) {
            app.globalData.user = res.data.data;
            app.globalData.telephone = res.data.data.telephone;
            me.setData({
                ads:res.data.data.ad.content,
                avatarUrl: app.globalData.userInfo.avatarUrl,
                nickName: app.globalData.userInfo.nickName,
                user: res.data.data
            })
        }, "POST");
    },
    call(){
        wx.makePhoneCall({
            phoneNumber: app.globalData.telephone,
        })
    },
    onPullDownRefresh: function () {
        this.onShow();
        wx.stopPullDownRefresh()
    },
    onShareAppMessage: util.onShareAppMessage
})